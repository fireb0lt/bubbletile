//
//  SKNode+TouchPriority.h
//  ButtonLab
//
//  Created by Fille Åström on 10/20/13.
//  Copyright (c) 2013 IMGNRY. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface SKNode (TouchPriority)

- (NSString *)nodeDepthPriority;

@end
